myApp.controller('AllAPIController', ['$rootScope', '$scope',  'SearchDataService', '$http', '$location', '$localStorage', '$cookies',
    function($rootScope, $scope,  SearchDataService, $http, $location, $localStorage, $cookies) {
        $scope.userName=$localStorage.Username;
          
            $http.get("https://yqnscqdbld.execute-api.us-east-1.amazonaws.com/prod/Ambulance",{
                    
                }).success(
                    function(respon) {
                        
                        $scope.apiarray = respon.Items;

                    }).error(function(err) {
                        $location.path('/dashboard');                   
                });

                $scope.book= function(VehicleNumber){
                    
                    $scope.vehicle=VehicleNumber
                    
                }

                $scope.ambulanceBook = function() {
                    console.log($scope.vehicle)
                        var request = {
                                      method: 'PUT',
                                         url: "https://yqnscqdbld.execute-api.us-east-1.amazonaws.com/prod/updateambulance",
                                         data: {
                                                 "VehicleNumber": $scope.vehicle,
                                                 "Available":"No"
                                                  }
                                                } 
                        $http(request,{
                    }).success(function(respon){console.log(respon)
                        $location.path('/ambList')}
                    
                ).error(function(err){
                        console.log(err);
                    })
        
                var req={
                    method:'GET',
                    url:"https://20sxm98xt6.execute-api.us-east-1.amazonaws.com/prod/Twilio?to="+$scope.mobile,
                 
                }

                    $http(req,{
                    }).success(function(respon){
                        console.log(respon)
                        $location.path('/ambList')}
                    
                ).error(function(err){
                        console.log(err);
                    })
            }   
        
     }
    

    
]);





