myApp.controller('AllAPIController', ['$rootScope', '$scope','$route',  'SearchDataService', '$http', '$location', '$localStorage', '$cookies' ,'$window',
    function($rootScope, $scope,  SearchDataService, $route, $http, $location, $localStorage, $cookies,$window) {
        
        $scope.hideSpan = true;
        $scope.hideForm = false;
        $scope.userName=$localStorage.Username;
          
            $http.get("https://yqnscqdbld.execute-api.us-east-1.amazonaws.com/prod/Ambulance",{    
                }).success(
                    function(respon) {
                    $scope.apiarray = respon.Items;
                    }).error(function(err) {
                        console.log(err)                   
                });

                $scope.book= function(VehicleNumber){
                    $scope.vehicle=VehicleNumber  
                }

                $scope.ambulanceBook = function() {
                    console.log($scope.vehicle)
                        var request = {
                                      method: 'PUT',
                                         url: "https://yqnscqdbld.execute-api.us-east-1.amazonaws.com/prod/updateambulance",
                                         data: {
                                                 "VehicleNumber": $scope.vehicle,
                                                 "Available":"No"
                                                  }
                                                } 
                        $http(request).success(function(respon){
                       
                    } ).error(function(err){
                        console.log(err);
                    })
        
               
                    var req={
                        method:'GET',
                        url:"https://20sxm98xt6.execute-api.us-east-1.amazonaws.com/prod/Twilio?to="+$scope.mobile,
                     
                    }
                    $http(req).success(function(respon){
                        console.log(respon)
                        $scope.hideSpan = false;
                        $scope.hideForm = true;
                        $scope.id=respon.id;
                        setTimeout(function(){ $window.location.reload(); },3000);
                    }
                    
                ).error(function(err){
                        $window.alert("SMS cannot send on \n"+ $scope.mobile +" Mobile No: 9198000448 is only registered in Twilio to recieve the sms")
                        console.log(err);
                    })
                    
            }   
        
     }
]);





