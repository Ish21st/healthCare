myApp.controller('DashboardController', ['$rootScope', '$scope', '$localStorage', '$cookies',  '$http', '$location', 'md5',
    function($rootScope, $scope, $localStorage, $cookies, $http, $location, md5) {
$scope.index=0


$http.get("https://45eoln47zh.execute-api.us-east-1.amazonaws.com/prod/Laboratory",{
                    
}).success(
    function(respon) {
        console.log(respon)
        $scope.apiarray = respon.Items;
    }).error(function(err) {
    if (err.message === 'jwt malformed' || err.message === 'invalid signature' || err.message === 'jwt expired') {
        $cookies.remove('globals');
        $rootScope.$destroy();
        window.alert("Sorry! Your Session Expired. \n Please Login Again.");
        $location.path('/login');
    }
});



        $scope.symptons= [{
            "ID": 17,
            "Name": "Chest pain"
        },
    
    
        {
            "ID": 15,
            "Name": "Cough"
        },
    
         {
            "ID": 228,
            "Name": "Cough with sputum"
        },
    
         {
            "ID": 108,
            "Name": "Dark urine"
        },
    
        {
            "ID": 50,
            "Name": "Diarrhea"
        },
    
          {
            "ID": 207,
            "Name": "Dizziness"
        },
         {
            "ID": 43,
            "Name": "Drowsiness"
        },
          {
            "ID": 11,
            "Name": "Fever"
        },
        {
            "ID": 186,
            "Name": "Hand pain"
        },
        {
            "ID": 206,
            "Name": "Hearing loss"
        },
        {
            "ID": 73,
            "Name": "Itching eyes"
        },
     ]

     
     $scope.checkSymptons = function(ID) {
        $scope.Hide=false;
            var request = {
                          method: 'GET',
                             url: "https://priaid-symptom-checker-v1.p.mashape.com/diagnosis?gender=male&language=en-gb&symptoms=["+ID+"]&year_of_birth=1993",
                             headers:{
                                 'X-Mashape-Key':'04QmcwgpU3mshszotZvORhGd0nQkp1eDHFXjsnVLql0Isnx5zA',
                                 'Accept':'application/json'
                             }
                            
            }
            $http(request,{
        }).success(function(respon){
            $scope.diagnoseArray=respon;
         
        }).error(function(err){
           console.log(err)
        })
      
        
           
    }  

   
    $scope.userName=$localStorage.Username;
   
    $scope.submitBMI = function() {
      
       console.log($scope.gender);
console.log("in submitBMI")
        var request = {
            method: 'POST',
               url: "https://bmi.p.mashape.com/",
               data:{"weight":{"value":$scope.weight,"unit":"kg"},"height":{"value":$scope.height,"unit":"cm"},"sex":$scope.gender,"age":$scope.age},
               headers:{
                'X-Mashape-Key':'04QmcwgpU3mshszotZvORhGd0nQkp1eDHFXjsnVLql0Isnx5zA',
                'Accept':'application/json'
            }
            }
        $http(request,{
        }).success(function(respon){console.log(respon)
           
            $scope.value=respon.bmi.value;
            $scope.status=respon.bmi.status;
            $scope.risk=respon.bmi.risk;
        }).error(function(err){
            console.log(err);
        })
    };

    }
]);