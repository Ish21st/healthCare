myApp.controller('LaboratoryController', ['$rootScope', '$scope',  'SearchDataService','$http', '$localStorage', '$location', '$cookies',
    function($rootScope, $scope,  SearchDataService, $http, $localStorage, $location, $cookies) {
        $scope.userName=$localStorage.Username;
        $http.get("https://45eoln47zh.execute-api.us-east-1.amazonaws.com/prod/Laboratory",{
                    
                }).success(
                    function(response) {
                        
                        $scope.apiarray = response.Items;

                    }).error(function(err) {
                        $location.path('/dashboard');                   
                });


         $scope.book= function(registrationNumber,labName){
             
             $scope.registrationNumber=registrationNumber
             $scope.labName=labName

         }   

         $scope.labBook = function() {    
             console.log($scope.mobile);
             console.log($scope.Name);
             console.log($scope.registrationNumber)
             console.log($scope.ad)
             console.log($scope.labName)
                var request = {
                              method: 'POST',
                                 url: "https://hh2ue9gx5a.execute-api.us-east-1.amazonaws.com/prod/Appointment",
                                 data: {
                                         "name": $scope.Name,
                                         "mobile":$scope.mobile,
                                         "registration":$scope.registrationNumber,
                                         "lab":$scope.labName,
                                         "date":$scope.ad
                                          }
                }
                $http(request).success(function(respon){console.log(respon)

                var req={
                    method:'GET',
                    url:"https://20sxm98xt6.execute-api.us-east-1.amazonaws.com/prod/Twilio?to="+$scope.mobile,
                 }   
                $http(req).success(function(respon){
                    alert("Confirmation sms sent on ur mobile.  confirmation id is "+respon.id)
                        $location.path('/lab')
                    
                    }).error(function(err){
                        console.log(err);
                    })

              }
        ).error(function(err){
                console.log(err);
            })



           
        }   
                       
     }
            

     
    
]);