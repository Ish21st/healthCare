myApp.controller('LaboratoryController', ['$rootScope', '$scope',  'SearchDataService','$http','$window','$localStorage', '$location', '$cookies',
    function($rootScope, $scope,  SearchDataService,$http, $window,  $localStorage, $location, $cookies) {

        $scope.hideSpan = true;
        $scope.hideForm = false;
        $scope.userName=$localStorage.Username;
        $http.get("https://45eoln47zh.execute-api.us-east-1.amazonaws.com/prod/Laboratory",{
                    
                }).success(
                    function(response) {
                        
                        $scope.apiarray = response.Items;

                    }).error(function(err) {
                        $location.path('/dashboard');                   
                });


         $scope.book= function(registrationNumber,labName){
             
             $scope.registrationNumber=registrationNumber
             $scope.labName=labName

         }   

         $scope.labBook = function() {    
                var request = {
                              method: 'POST',
                                 url: "https://hh2ue9gx5a.execute-api.us-east-1.amazonaws.com/prod/Appointment",
                                 data: {
                                         "name": $scope.Name,
                                         "mobile":$scope.mobile,
                                         "registration":$scope.registrationNumber,
                                         "lab":$scope.labName,
                                         "date":$scope.ad
                                          }
                }
                $http(request).success(function(respon){
                   
              }
        ).error(function(err){
                console.log(err);
            })

            var req={
                method:'GET',
                url:"https://20sxm98xt6.execute-api.us-east-1.amazonaws.com/prod/Twilio?to="+$scope.mobile,
             }   
            $http(req).success(function(respon){
                $scope.id=respon.id;
                $scope.hideSpan = false;
                $scope.hideForm = true
                 
                 setTimeout(function(){ $window.location.reload(); },3000);
                
                }).error(function(err){
                    $window.alert("SMS cannot send on "+ $scope.mobile +" \n Mobile No: 9198000448 is only registered in HealthCare Twilio to recieve the sms")
                    console.log(err);
                })


           
        }   
                       
     }
            

     
    
]);