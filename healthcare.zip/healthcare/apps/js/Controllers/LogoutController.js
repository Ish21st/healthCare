myApp.controller('LogoutController', ['$rootScope', '$scope', '$http', '$localStorage', '$location', '$cookies',
    function($rootScope, $scope, $http, $localStorage, $location, $cookies) {
        $localStorage.$reset()
        $cookies.remove('globals');
        $location.path('/login');

    }
]);