//LoginController

myApp.controller('LoginController', ['$rootScope','$scope', '$http', '$location', '$localStorage', '$cookies',
    function($rootScope, $scope, $http, $location, $localStorage, $cookies) {


        $scope.login= function(){
            $cookies.put('globals',$scope.userName.split("@")[0]);
            $localStorage.Username=$scope.userName.split("@")[0];
            $location.path('/dashboard');

        }



     $scope.onGoogleLogin= function(){
        gapi.auth2.authorize({
            client_id: '766569291489-rhou3uqt1rjc1q068hocrhirh9hr5hbh.apps.googleusercontent.com',
            scope: 'profile email openid',
            response_type: 'id_token permission',
            prompt: 'select_account'
        }, function(response) {
            if (response.error) {
                window.alert(data.message);
                return;
        }
           
            var accessToken = response.access_token;
            var idToken = response.id_token;
            var res = $http.get("https://www.googleapis.com/oauth2/v3/tokeninfo?id_token="+idToken)
            res.success(function(data, status, headers, config) {
                     $cookies.put('globals',idToken);
                     $localStorage.Username=data.name;
                     console.log($localStorage.Username)
                     $location.path('/dashboard');
                    
            }).error(function(data, status, headers, config) {
                    window.alert(data.message);
            });
        });
      }
    }
]);

