//LoginController

myApp.controller('LoginController', ['$rootScope', '$scope', '$http', '$location', '$localStorage', '$cookies',
    function($rootScope, $scope,  $http, $location, $localStorage, $cookies) {
    $scope.onGoogleLogin= function(){
        gapi.auth2.authorize({
            client_id: '766569291489-c1mpuj9jlur711l21f446evr2fnf3qni.apps.googleusercontent.com',
            scope: 'email profile openid',
            response_type: 'id_token permission',
            prompt: 'select_account'
        }, function(response) {
            if (response.error) {
                window.alert(data.message);
                return;
        }// The user authorized the application for the scopes requested.
           
            var accessToken = response.access_token;
            var idToken = response.id_token;
            var res = $http.get("https://www.googleapis.com/oauth2/v3/tokeninfo?id_token="+idToken)
            res.success(function(data, status, headers, config) {
                     $cookies.put('globals',idToken);
                     $localStorage.Username=data.name;
                     $location.path('/dashboard');
                    
            }).error(function(data, status, headers, config) {
            window.alert(data.message);
            });
        });
      }
    }
]);

