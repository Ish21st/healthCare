//SearchController
myApp.controller('AmbulanceBookingController', ['$rootScope', '$scope',  'SearchDataService','$http', '$location', '$cookies', '$localStorage',
    function($rootScope, $scope,   SearchDataService, $http, $location, $cookies, $localStorage) {

        $scope.userName=$localStorage.Username;
   
    console.log("Insearch controler")
    }
]);
