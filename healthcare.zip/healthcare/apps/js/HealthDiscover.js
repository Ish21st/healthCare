var myApp = angular.module('myApp', ["textAngular", 'ngStorage', 'ngRoute', 'ngSanitize', 'swaggerUi', 'ngCookies' , 'angular-md5'/*,'ngMaterial'*/ ]);




myApp.constant('StaticFile', '');
myApp.constant('UserManagement', '');





myApp.config(['$routeProvider', function($routeProvider) {
    $routeProvider.
    when('/login', {
        templateUrl: '../apps/views/login.html',
        controller: 'LoginController'
    }).
    when('/ambBooking', {
        templateUrl: '../apps/views/ambulanceBooking.html',
        controller: 'AmbulanceBookingController'
    }).
   
    when('/ambList', {
        templateUrl: '../apps/views/ambulanceList.html',
        controller: 'AllAPIController'
    }).
    when('/dashboard', {
        templateUrl: '../apps/views/dashboard.html',
        controller: "DashboardController"
    }).
    when('/logout', {
        templateUrl: '/apps/views/login.html',
        controller: 'LogoutController'
    }).when('/lab', {
        templateUrl: '/apps/views/laboratoryList.html',
        controller: 'LaboratoryController'
    }).otherwise({
        redirectTo: '/login'
    });
}]);


myApp.directive('lablist', function(){
    return{
        templateurl: '/apps/views/Laboratory.html'
    }
})

myApp.directive('leftcol', function() {
    return {
        templateUrl: '/apps/views/leftcolumn.html'
    };
});
myApp.directive('apilist', function() {
    return {
        templateUrl: '/apps/views/ambList.html'
    };
});
myApp.directive('loading', ['$http', function($http) {
    return {
        restrict: 'A',
        link: function(scope, elm, attrs) {
            scope.isLoading = function() {
                return $http.pendingRequests.length > 0;
            };
            scope.$watch(scope.isLoading, function(v) {
                if (v) {
                    elm.show();
                } else {
                    elm.hide();
                }
            });
        }
    };
}]);



myApp.service('SearchDataService', function() {
    var keyword = null

    var addKeyword = function(newObj) {
        keyword = newObj
    };

    var getKeyword = function() {
        return keyword;
    };
    var removeKeyword = function() {
        keyword = null
    }
    return {
        addKeyword: addKeyword,
        getKeyword: getKeyword,
        removeKeyword: removeKeyword
    };
});
myApp.run(['$rootScope', '$location', 'UserManagement', '$window', '$sessionStorage', '$route', '$cookies', '$http', function($rootScope, $location, UserManagement, $window, $sessionStorage, $route, $cookies, $http) {

    $rootScope.SwaggerURL = 'nothing';
    $rootScope.similarApi = 'nothing';
    $rootScope.$on('$locationChangeSuccess', function() {

        $rootScope.actualLocation = $location.path();

        if ($cookies.get('globals') === undefined && $location.path() !== '/register' && !/\/verify*/.test($location.path()) && $location.path() !== '/forgotPassword') {

            $location.path('/login');
        }
        if ($cookies.get('globals') !== undefined && ($location.path() === '/register' || /\/verify*/.test($location.path()) || $location.path() === '/forgotPassword' || $location.path() === '/login' )) {

            $location.path('/dashboard');
        }

    });
}]);