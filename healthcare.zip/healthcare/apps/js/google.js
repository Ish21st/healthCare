function onLoadFunction()
{
    gapi.client.setApiKey('AIzaSyBdAsIg-nwtEnbe65Qcxjr2X8GpdbZpAdA');
   
}