myApp.factory('AuthenticationService',
    ['Base64', '$http', 'APEvolveAPI', '$cookieStore', '$rootScope', '$timeout',
    function ( Base64, $http, APEvolveAPI , $cookieStore, $rootScope, $timeout) {
        var service = {};

        service.Login = function (username, password, callback) {

            /* Dummy authentication for testing, uses $timeout to simulate api call
             ----------------------------------------------*/
           /* $timeout(function(){
                var response = { success: username === 'test' && password === 'test' };
                $rootScope.user= username;
                if(!response.success) {
                   
                    response.message = 'Username or password is incorrect';
                }

                callback(response);
            }, 1000);*/

     //   http://localhost:8089/APEvolve_Rest/rest/session/logincheck
            /* Use this for real authentication
             ----------------------------------------------*/
       var myvalue;
      
       console.log("i m in service area");
             var parameter = JSON.stringify({userName:username, password:password});
            $http.post(APEvolveAPI + '/APEvolveRest2/rest/session/logincheck', parameter)
                .success(function (respon) {
                    console.log("i m in service area more deep");
          $rootScope.myvalue=respon;
          console.log($rootScope.myvalue.message);
          console.log($rootScope.myvalue.role);
                    var response = { succes: $rootScope.myvalue.message === 'Login Successful!' && $rootScope.myvalue.loginCode ==='S' , user:username ,role : $rootScope.myvalue.role,token :$rootScope.myvalue.token};
          if(!response.succes) {
                   
                    response.message = 'Username or password is incorrect';
                }
               
        callback(response);
        
                }); 
        
        
        };
 service.Registration= function(FirstName,LastName,Email,Password,Phone,Designation,Company ,callback){

       var myvalue;
       console.log("i m in Registration area");
             var parameter = JSON.stringify({firstName:FirstName, lastName:LastName, email:Email,password: Password,phone:Phone,designation:Designation,company:Company});
            $http.post(APEvolveAPI + '/APEvolveRest2/rest/session/saveSignUpDetails', parameter)
                .success(function (respon) {
          $rootScope.myvalue=respon;
          console.log($rootScope.myvalue.message);
                    var response = { succes: $rootScope.myvalue.message === 'Signup Successful!' && $rootScope.myvalue.signupCode ==='S' , user:Email };
          if(!response.succes) {
                   
                    response.message = 'Registration failed Please Check the Value U entered.';
                }
        callback(response);
        
                }); 

 };
 
 service.AcceptRequest= function(value,callback){

     var myvalue;
     console.log("i m in Registration area");
           var parameter = JSON.stringify({firstName:value.firstName, lastName:value.lastName, email:value.email,phone:value.phone,designation:value.designation,company:value.company});
          $http.post(APEvolveAPI + '/APEvolveRest2/rest/masterdata/approveregistereduser', parameter)
              .success(function (respon) {
        $rootScope.myvalue=respon;
        console.log($rootScope.myvalue.message);
                  var response = { succes: $rootScope.myvalue.message === 'User approval Successful!' && $rootScope.myvalue.signupCode ==='S' , user:Email };
        if(!response.succes) {
                 
                  response.message = 'Approval Failed.';
              }
      callback(response);
      
              }); 

};
 
 
        service.SetCredentials = function (username, password, role,token) {
            var authdata = Base64.encode(username + ':' + password);
 
            $rootScope.globals = {
                currentUser: {
                    username: username,
                    authdata: authdata,
                    role:role,
                    token:token
                }
            };
 
            $http.defaults.headers.common['Authorization'] = 'Bearer ' + token ; 
            $cookieStore.put('globals', $rootScope.globals);
        };
 
        service.ClearCredentials = function () {
            $rootScope.globals = {};
            $cookieStore.remove('globals');
            $http.defaults.headers.common.Authorization = 'Basic ';
        };
 
        return service;
    }])